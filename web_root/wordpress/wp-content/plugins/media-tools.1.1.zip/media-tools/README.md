Media Tools for WordPress
=========================

### A set of tools to help manage your media library.  

Big improvements are coming to the WordPress media library in 3.5.  If your not using the media library this plugin will
import all the external images found in your posts or pages and import them into the media library and attach them.

This plugin will help you recover from your Timthumb addiction.  If you have been using Timthumb now is the time to come clean.  


### The Tools

* Import and attach - imports and attaches all external referenced images in your posts
* Set Featured Image - finds the first attached image to post and sets it as the featured image
* Import media from a directory on your server and add them to your media library
* Add post thumbnail support to your site set thumbnail sizes
* More tools coming soon....
 

Control and filter the import script by post type, author, date range, or category.

Ajax interface that converts the images with one simple click.